// ES6 Modules
export const hello = ()=>{
    console.log("Hello Harry")
}

export const ahello = (name)=>{
    console.log("Hello " + name)
}

const harry = ()=>{
    console.log("Hello " + "Harry")
}

export default harry;
 